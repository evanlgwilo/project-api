export type OrderType = {
  foodId: string;
  count: number;
};
